plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "org.example.automediacollector"
    compileSdk = 35
    defaultConfig {
        applicationId = "org.example.automediacollector"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("org.jsoup:jsoup:1.18.3") }
