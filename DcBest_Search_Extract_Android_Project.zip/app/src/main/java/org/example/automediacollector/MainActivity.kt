package org.example.automediacollector

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.method.ScrollingMovementMethod
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var output: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "DCBest ㅇㅎ 검색·추출 테스트"
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 30, 28, 24)
        }
        val description = TextView(this).apply {
            text = "실시간 베스트 → 제목 ㅇㅎ 검색 → 검색 결과 게시글 → 이미지/동영상 URL 추출\\n다운로드 없음 · 검색 결과 최대 20개"
            textSize = 16f
        }
        val button = Button(this).apply { text = "검색 및 추출 시작" }
        output = TextView(this).apply {
            text = "버튼을 눌러 실제 기기에서 HTTP 접속을 시험하세요."
            textSize = 13f
            setTextIsSelectable(true)
            movementMethod = ScrollingMovementMethod()
        }
        val scroll = ScrollView(this).apply { addView(output) }
        column.addView(description)
        column.addView(button)
        column.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(column)

        button.setOnClickListener {
            button.isEnabled = false
            output.text = "접속 시작...\\n"
            executor.execute {
                SearchExtractor.run { line ->
                    main.post { output.append(line + "\\n") }
                }
                main.post { button.isEnabled = true }
            }
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
