package org.example.automediacollector

import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.net.URI
import java.net.URLEncoder

object SearchExtractor {
    private const val SEARCH = "https://m.dcinside.com/board/dcbest?s_type=subject_m&serval=%E3%85%87%E3%85%8E&recommend=&headid="
    private const val MAX_POSTS = 20

    fun run(log: (String) -> Unit) {
        try {
            log("검색 URL: $SEARCH")
            val list = fetch(SEARCH)
            log("검색 페이지 수신: ${list.title()} / ${list.location()}")
            val found = linkedMapOf<String, String>()
            for (a in list.select("a[href]")) {
                val href = a.absUrl("href").substringBefore("#")
                val title = a.text().trim()
                if (!title.contains("ㅇㅎ")) continue
                val uri = runCatching { URI(href) }.getOrNull() ?: continue
                if (uri.scheme != "https" || uri.host !in setOf("m.dcinside.com", "gall.dcinside.com")) continue
                val path = uri.path.orEmpty()
                val isPost = path.startsWith("/board/dcbest/") && path.removePrefix("/board/dcbest/").all { it.isDigit() } && path.length > "/board/dcbest/".length
                val isDesktopPost = path.contains("/board/view") && uri.rawQuery.orEmpty().contains("id=dcbest")
                if (!isPost && !isDesktopPost) continue
                found[href] = title
            }
            log("제목 ㅇㅎ 게시글 링크: ${found.size}개")
            if (found.isEmpty()) {
                log("0건: 검색 결과가 없거나 HTML 구조가 달라 파싱되지 않았습니다.")
                log("확인용 제목 예시: " + list.select("a[href]").map { it.text().trim() }.filter { it.isNotBlank() }.take(8).joinToString(" | "))
            }
            found.entries.take(MAX_POSTS).forEachIndexed { index, (url, title) ->
                log("\\n[${index + 1}] $title")
                log("게시글: $url")
                try {
                    val post = fetch(url)
                    val urls = linkedSetOf<String>()
                    for (element in post.select("img, video, source, a[href]")) {
                        val attrs = listOf("src", "data-src", "data-original", "data-lazy-src", "poster", "href")
                        for (attr in attrs) {
                            if (!element.hasAttr(attr)) continue
                            val candidate = element.absUrl(attr)
                            if (isMedia(candidate)) urls.add(candidate)
                        }
                        if (element.hasAttr("srcset")) {
                            element.attr("srcset").split(",").forEach { part ->
                                val raw = part.trim().substringBefore(" ")
                                val candidate = runCatching { URI(url).resolve(raw).toString() }.getOrDefault("")
                                if (isMedia(candidate)) urls.add(candidate)
                            }
                        }
                    }
                    log("미디어 후보: ${urls.size}개")
                    urls.take(40).forEach { log("  $it") }
                    if (urls.isEmpty()) log("  추출 없음 (동적 로딩 또는 사이트 구조 차이 가능)")
                } catch (e: Exception) {
                    log("게시글 오류: ${e.javaClass.simpleName}: ${e.message}")
                }
            }
            log("\\n완료. 실제 파일 다운로드는 하지 않았습니다.")
        } catch (e: Exception) {
            log("검색 실패: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun fetch(url: String): Document =
        Jsoup.connect(url)
            .userAgent("Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36")
            .referrer("https://m.dcinside.com/")
            .header("Accept-Language", "ko-KR,ko;q=0.9")
            .timeout(18000)
            .maxBodySize(5_000_000)
            .followRedirects(true)
            .get()

    private fun isMedia(url: String): Boolean {
        val uri = runCatching { URI(url) }.getOrNull() ?: return false
        if (uri.scheme != "https" || uri.host.isNullOrBlank()) return false
        val path = uri.path.orEmpty().lowercase()
        return listOf(".jpg", ".jpeg", ".png", ".gif", ".webp", ".mp4", ".webm", ".m3u8")
            .any { path.endsWith(it) } ||
            uri.host!!.contains("dcimg") || uri.host!!.contains("dcinside") && path.contains("/viewimage")
    }
}
