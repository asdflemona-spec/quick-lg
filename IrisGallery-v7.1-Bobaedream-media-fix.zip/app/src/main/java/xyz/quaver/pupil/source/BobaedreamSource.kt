package xyz.quaver.pupil.source

import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.isSuccess
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import xyz.quaver.pupil.client
import java.io.IOException
import java.net.URI

/** Independent public-board adapter; never mixes post IDs between the two boards. */
class BobaedreamSource(private val board: String) : ContentSource {
    init { require(board == "nsfw" || board == "girl") }
    override val id = "bobaedream_$board"
    override val displayName = if (board == "nsfw") "Bobaedream NSFW" else "Bobaedream Girl"
    override val maturity = if (board == "nsfw") SourceMaturity.ADULT else SourceMaturity.GENERAL
    override val availability = SourceAvailability.READY
    override val capabilities = setOf(SourceCapability.BROWSE, SourceCapability.DETAIL,
        SourceCapability.MULTI_IMAGE, SourceCapability.VIDEO, SourceCapability.DOWNLOAD)
    private val base = "https://m.bobaedream.co.kr"
    private val boardUrl = "$base/board/new_writing/$board"
    val requestHeaders = mapOf("Referer" to "$base/", "User-Agent" to
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")

    private suspend fun document(url: String): Document {
        val response = client.get(url) { requestHeaders.forEach { (k, v) -> header(k, v) } }
        if (!response.status.isSuccess()) throw IOException("Bobaedream HTTP ${response.status.value}")
        return Jsoup.parse(response.bodyAsText(), url)
    }

    override suspend fun search(query: String, page: Int): SourcePage {
        require(page >= 0)
        // Search is a local title filter of the fetched board page, not a site-wide search.
        val doc = document(if (page == 0) boardUrl else "$boardUrl/${page + 1}")
        val seen = hashSetOf<String>()
        val items = doc.select("a[href*=/board/bbs_view/]").mapNotNull { a ->
            val url = a.absUrl("href")
            val match = Regex("/board/bbs_view/(nsfw|girl)/(\\d+)(?:/|$)").find(URI(url).path ?: "")
                ?: return@mapNotNull null
            if (match.groupValues[1] != board) return@mapNotNull null
            val remoteId = match.groupValues[2]
            if (!seen.add(remoteId)) return@mapNotNull null
            val title = a.text().trim().ifBlank { a.attr("title").trim() }
            if (title.isBlank() || (query.isNotBlank() && !title.contains(query, ignoreCase = true))) return@mapNotNull null
            val thumb = a.closest("li, tr, .list, .item")?.selectFirst("img")?.let(::mediaUrl)
            SourceItem(id, remoteId, title, thumb, url)
        }
        val hasNext = doc.select("a[href]").any { a ->
            val path = runCatching { URI(a.absUrl("href")).path }.getOrNull()
            path == "/board/new_writing/$board/${page + 2}"
        }
        return SourcePage(items, if (hasNext) page + 1 else null)
    }

    override suspend fun detail(remoteId: String): SourceDetail {
        require(remoteId.matches(Regex("[0-9]+")))
        val url = "$base/board/bbs_view/$board/$remoteId"
        val doc = document(url)
        val title = doc.selectFirst("h3, h2, h1")?.text()?.trim()?.takeIf { it.isNotBlank() } ?: doc.title()
        // The post body must be isolated: the global page contains search/magnifier
        // icons and unrelated images which must never enter the viewer/download list.
        val selectors = listOf(
            "#bo_v_con", "#view_content", "#viewContent", "#bbs_view_content",
            ".view_content", ".viewContent", ".bodyCont", ".board-view",
            ".article_view", ".content_view", "#bodyContent", ".board_view_cont",
            ".view_txt", ".view_body", ".viewCont", ".article-content",
            "[id*=view_content]", "[class*=view_content]"
        )
        val candidates = selectors.flatMap { doc.select(it) }.distinct()
        val scope = candidates.firstOrNull { root ->
            root.select("img, video, source, a[href]").any { element ->
                imageCandidates(element).isNotEmpty()
            }
        } ?: doc.body()

        val media = linkedSetOf<String>()
        scope.select("img, video, source, a[href]").forEach { element ->
            imageCandidates(element).forEach(media::add)
        }
        // When the site changes its markup, a body-wide fallback can still find
        // image files, but must exclude navigation/search widgets and tiny icons.
        val filtered = media.filterNot(::isUiAsset)
        return SourceDetail(SourceItem(id, remoteId, title, filtered.firstOrNull(), url), filtered)
    }

    private fun imageCandidates(element: Element): List<String> {
        val found = linkedSetOf<String>()
        val attrs = listOf("data-original", "data-origin", "data-src", "data-lazy-src",
            "data-url", "data-image", "data-full", "data-echo", "src")
        for (attr in attrs) {
            mediaUrl(element, attr)?.takeIf(::looksLikeMedia)?.let(found::add)
        }
        for (attr in listOf("data-srcset", "srcset")) {
            element.attr(attr).split(',').forEach { part ->
                mediaUrlValue(part.trim().substringBefore(' '))
                    ?.takeIf(::looksLikeMedia)?.let(found::add)
            }
        }
        if (element.normalName() == "a") {
            mediaUrl(element, "href")?.takeIf(::looksLikeMedia)?.let(found::add)
        }
        return found.toList()
    }

    private fun isUiAsset(url: String): Boolean {
        val path = runCatching { URI(url).path.orEmpty().lowercase() }.getOrDefault(url.lowercase())
        val filename = path.substringAfterLast('/')
        return listOf("logo", "icon", "avatar", "emoji", "banner", "profile", "search",
            "zoom", "magnif", "btn_", "button", "favicon", "loading", "spinner",
            "blank", "noimage", "no_image").any { filename.contains(it) } ||
            path.contains("/common/") || path.contains("/images/btn") ||
            path.contains("/skin/") || path.contains("/assets/")
    }

    private fun mediaUrl(e: Element, attr: String = "src"): String? = mediaUrlValue(e.attr(attr))

    private fun mediaUrlValue(raw0: String): String? {
        val raw = raw0.trim().replace("&amp;", "&")
        if (raw.isBlank() || raw.startsWith("data:", true) ||
            raw.startsWith("javascript:", true) || raw.startsWith("blob:", true)) return null
        return runCatching {
            val uri = URI(base).resolve(raw)
            if (uri.scheme == "https" || uri.scheme == "http") uri.toString() else null
        }.getOrNull()
    }

    private fun looksLikeMedia(url: String): Boolean {
        val path = runCatching { URI(url).path.orEmpty().lowercase() }.getOrDefault("")
        return listOf(".jpg", ".jpeg", ".png", ".gif", ".webp", ".mp4", ".webm", ".mov", ".avif")
            .any { path.endsWith(it) } ||
            (path.contains("/image/") && !path.contains("/images/btn")) ||
            path.contains("/upload/") || path.contains("/editor/")
    }
}
