package com.overload.language;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import android.graphics.Color;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
  private Spinner language, mode;
  private TextView counter, output;
  private DB db;
  private TextToSpeech tts;
  private String currentText="";
  private final Random random = new Random();
  private final String[] codes={"en","ja","zh"};
  private final String[][] en={
    {"I want to", "저는 ~하고 싶어요", "learn", "배우다", "practice", "연습하다", "review", "복습하다", "understand", "이해하다"},
    {"Can you", "~해 줄 수 있나요?", "explain", "설명하다", "repeat", "반복하다", "check", "확인하다", "translate", "번역하다"},
    {"We should", "우리는 ~해야 해요", "compare", "비교하다", "discuss", "토론하다", "remember", "기억하다", "improve", "개선하다"}};
  private final String[][] ja={
    {"私は", "저는", "日本語を勉強します。", "일본어를 공부합니다.", "毎日練習します。", "매일 연습합니다.", "新しい単語を覚えます。", "새 단어를 외웁니다.", "文章を読みます。", "문장을 읽습니다."},
    {"今日は", "오늘은", "図書館に行きます。", "도서관에 갑니다.", "友達と話します。", "친구와 이야기합니다.", "本を読みます。", "책을 읽습니다.", "音楽を聞きます。", "음악을 듣습니다."},
    {"明日は", "내일은", "早く起きます。", "일찍 일어납니다.", "学校に行きます。", "학교에 갑니다.", "日本語を復習します。", "일본어를 복습합니다.", "家で勉強します。", "집에서 공부합니다."}};
  private final String[][] zh={
    {"我想", "저는 ~하고 싶어요", "学习中文。", "중국어를 공부하다", "练习发音。", "발음을 연습하다", "阅读文章。", "글을 읽다", "复习单词。", "단어를 복습하다"},
    {"今天我", "오늘 저는", "去图书馆。", "도서관에 갑니다.", "学习语法。", "문법을 공부합니다.", "听中文歌。", "중국어 노래를 듣습니다.", "写一封信。", "편지를 씁니다."},
    {"明天我", "내일 저는", "去学校。", "학교에 갑니다.", "练习口语。", "회화를 연습합니다.", "读一本书。", "책 한 권을 읽습니다.", "见我的朋友。", "친구를 만납니다."}};
  @Override public void onCreate(Bundle b){super.onCreate(b);db=new DB(this); LinearLayout page=new LinearLayout(this);page.setOrientation(1);page.setPadding(28,32,28,20);page.setBackgroundColor(Color.rgb(250,250,252)); ScrollView scroll=new ScrollView(this);scroll.addView(page);setContentView(scroll);
    TextView title=new TextView(this);title.setText("OverLoad Language · Offline");title.setTextSize(24);title.setTextColor(Color.rgb(30,45,75));page.addView(title);
    TextView subtitle=new TextView(this);subtitle.setText("기존 학습자료 + 오프라인 조합형 문장 생성기\n※ 이 버전은 AI 모델이 아닌 규칙 기반 생성기입니다.");subtitle.setPadding(0,14,0,18);page.addView(subtitle);
    language=new Spinner(this);language.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"English","日本語","中文"}));page.addView(language);
    mode=new Spinner(this);mode.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"새 문장 생성","기존 APK 학습자료"}));page.addView(mode);
    Button generate=new Button(this);generate.setText("새 학습자료 생성 / 보기");page.addView(generate);
    Button speak=new Button(this);speak.setText("문장 듣기 (기기 TTS)");page.addView(speak);
    counter=new TextView(this);counter.setTextSize(15);counter.setPadding(0,14,0,12);page.addView(counter);
    output=new TextView(this);output.setTextSize(21);output.setTextColor(Color.BLACK);output.setTextIsSelectable(true);output.setPadding(12,20,12,20);page.addView(output);
    tts=new TextToSpeech(this, status->{if(status==TextToSpeech.SUCCESS) tts.setSpeechRate(.88f);});
    generate.setOnClickListener(v->generate());speak.setOnClickListener(v->{if(tts!=null&&!currentText.isEmpty()){int l=language.getSelectedItemPosition();tts.setLanguage(l==0?Locale.US:l==1?Locale.JAPANESE:Locale.SIMPLIFIED_CHINESE);tts.speak(currentText,TextToSpeech.QUEUE_FLUSH,null,"overload");}});
    showCount();output.setText("언어를 선택한 다음 생성 버튼을 누르세요.");
  }
  private void showCount(){counter.setText("저장된 새 문장: "+db.count()+"개 (앱 내부 DB)");}
  private void generate(){int l=language.getSelectedItemPosition();if(mode.getSelectedItemPosition()==1){showOriginal(l);return;}
    String[][] bank=l==0?en:l==1?ja:zh;String code=codes[l];
    for(int tries=0;tries<100;tries++){
      String[] row=bank[random.nextInt(bank.length)];int n=2+random.nextInt(4)*2;
      String sentence=l==0?row[0]+" "+row[n]+" more effectively.":row[0]+row[n];
      String translation=l==0?row[1]+" · "+row[n+1]+" (학습용 표현)":row[1]+" "+row[n+1];
      if(db.add(code,sentence,translation)){currentText=sentence;output.setText(sentence+"\n\n"+translation+"\n\n[새 문장 · 오프라인 규칙 생성]");showCount();return;}
    }
    output.setText("현재 언어의 기본 조합을 모두 생성했습니다.\n추가 표현은 향후 AI 모델 연동이 필요합니다.");showCount();
  }
  private void showOriginal(int l){try{java.io.InputStream in=getAssets().open("curriculum.json");byte[] bytes=new byte[in.available()];int offset=0;while(offset<bytes.length){int n=in.read(bytes,offset,bytes.length-offset);if(n<0)break;offset+=n;}in.close();JSONArray courses=new JSONArray(new String(bytes,"UTF-8"));JSONObject course=courses.getJSONObject(l);JSONArray sentences=course.getJSONArray("sentences");JSONObject s=sentences.getJSONObject(random.nextInt(sentences.length()));currentText=s.getString("text");output.setText(currentText+"\n\n"+s.optString("translation")+"\n\n"+s.optString("note")+"\n\n[기존 APK 학습자료]");}catch(Exception e){output.setText("학습자료 읽기 실패: "+e.getMessage());}}
  @Override public void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}db.close();super.onDestroy();}
  static class DB extends SQLiteOpenHelper{
    DB(Context c){super(c,"overload_generated.db",null,1);}
    public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE entries(id INTEGER PRIMARY KEY, lang TEXT, text TEXT, translation TEXT, UNIQUE(lang,text))");}
    public void onUpgrade(SQLiteDatabase d,int a,int b){}
    boolean add(String lang,String text,String translation){android.content.ContentValues v=new android.content.ContentValues();v.put("lang",lang);v.put("text",text);v.put("translation",translation);return getWritableDatabase().insertWithOnConflict("entries",null,v,SQLiteDatabase.CONFLICT_IGNORE)!=-1;}
    int count(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM entries",null);try{c.moveToFirst();return c.getInt(0);}finally{c.close();}}
  }
}
