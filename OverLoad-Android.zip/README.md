# OverLoad Language — Android 소스 프로젝트

GitHub 저장소 루트에 **OverLoad-Android.zip** 이름으로 올리세요. 앞서 제공된 android.yml 워크플로우가 압축을 풀고 APK를 빌드합니다.

## 구현된 기능
- 원본 업로드 APK의 `curriculum.json` 및 MP3 48개 보존 (원본 MP3는 아직 UI 재생에 연결되지 않음)
- 영어·일본어·중국어 학습 문장 표시
- 스마트폰 오프라인 규칙 기반 문장 생성, SQLite 저장 및 중복 방지
- 기기에 해당 언어 TTS가 설치되어 있다면 읽어주기

## 중요한 제한
**이 프로젝트는 실제 AI 모델을 포함하지 않습니다.** 현재 생성기는 제한된 조합을 사용하는 규칙 기반 프로토타입이며 무한 생성이 아닙니다. 실제 오프라인 AI를 위해서는 별도 GGUF 모델, Android 네이티브 추론 엔진(llama.cpp 등), 모델 저장·다운로드 UI, JSON 검증이 추가되어야 합니다. 모델 라이선스와 기기 RAM을 확인하세요.

## 빌드
Android Gradle Plugin 8.7.3 / Java 17 / compileSdk 35. Android SDK가 있는 환경에서 `gradle assembleDebug`를 실행합니다. GitHub Actions에서 빌드하세요.

## 원본과의 관계
원본 APK의 자산을 재사용하는 **별도 Android 앱**입니다. 원본 APK의 서명키/소스가 없으므로 기존 앱에 덮어쓰기 업데이트가 되지 않습니다. 앱 ID: `com.overload.language.community`.
