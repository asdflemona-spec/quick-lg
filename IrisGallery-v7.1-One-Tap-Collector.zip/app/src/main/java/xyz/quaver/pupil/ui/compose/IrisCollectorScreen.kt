package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import xyz.quaver.pupil.source.*
import xyz.quaver.pupil.util.IrisSourceActions

/** Manual, bounded collection; no background schedule and no change to original photos. */
@Composable
fun IrisCollectorScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val sources = remember { SourceRegistry.ready }
    val selected = remember { mutableStateMapOf<String, Boolean>() }
    var limit by remember { mutableFloatStateOf(30f) }
    var random by remember { mutableStateOf(false) }
    var running by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Choose sources and press Start") }
    var saved by remember { mutableIntStateOf(0) }
    var skipped by remember { mutableIntStateOf(0) }
    var failed by remember { mutableIntStateOf(0) }
    var job by remember { mutableStateOf<Job?>(null) }
    DisposableEffect(Unit) { onDispose { job?.cancel() } }

    Column(modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("One-Tap Collector", style = MaterialTheme.typography.headlineSmall)
        Text("Manual download · stored in Pictures/Iris · no scheduled collection", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        sources.forEach { source ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(source.displayName)
                Checkbox(checked = selected[source.id] == true, enabled = !running, onCheckedChange = { selected[source.id] = it })
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Maximum images: ${limit.toInt()}")
        Slider(value = limit, onValueChange = { limit = it }, valueRange = 10f..200f, steps = 18, enabled = !running)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FilterChip(selected = !random, onClick = { random = false }, enabled = !running, label = { Text("Latest") })
            FilterChip(selected = random, onClick = { random = true }, enabled = !running, label = { Text("Random pages") })
        }
        Text("Duplicates are skipped on later runs. Stop cancels remaining requests.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(enabled = !running && sources.any { selected[it.id] == true }, onClick = {
                val chosen = sources.filter { selected[it.id] == true }
                val maxImages = limit.toInt()
                val randomPages = random
                saved = 0; skipped = 0; failed = 0; running = true
                job = scope.launch {
                    try {
                        val prefs = context.getSharedPreferences("iris_collector_seen_v1", android.content.Context.MODE_PRIVATE)
                        val visited = mutableSetOf<String>()
                        for (source in chosen) {
                            if (saved >= maxImages) break
                            val pages = if (randomPages) (0..9).shuffled() else (0..9).toList()
                            for (page in pages) {
                                if (saved >= maxImages) break
                                status = "${source.displayName}: page ${page + 1}"
                                val result = try { withContext(Dispatchers.IO) { source.browse(page) } } catch (e: CancellationException) { throw e } catch (_: Exception) { failed++; continue }
                                val entries = if (randomPages) result.items.shuffled() else result.items
                                for (item in entries) {
                                    if (saved >= maxImages) break
                                    if (!visited.add("${source.id}:${item.remoteId}")) continue
                                    val detail = try { withContext(Dispatchers.IO) { source.detail(item.remoteId) } } catch (e: CancellationException) { throw e } catch (_: Exception) { failed++; continue }
                                    val headers = when (source) {
                                        is GgoorrSource -> source.requestHeaders
                                        is BobaedreamSource -> source.requestHeaders
                                        is DcinsideSource -> source.requestHeaders
                                        else -> emptyMap()
                                    }
                                    for (url in detail.imageUrls) {
                                        if (saved >= maxImages) break
                                        if (IrisSourceActions.isVideoUrl(url)) continue
                                        val unique = "${source.id}:${url}"
                                        if (prefs.getBoolean(unique, false)) { skipped++; continue }
                                        status = "Saving ${saved + 1} / $maxImages · ${source.displayName}"
                                        // Unique name per URL prevents collisions within a post.
                                        val single = detail.copy(item = detail.item.copy(remoteId = "${detail.item.remoteId}_${url.hashCode().toUInt().toString(16)}"), imageUrls = listOf(url))
                                        val count = try { withContext(Dispatchers.IO) { IrisSourceActions.download(context, single, headers, notify = false) } } catch (e: CancellationException) { throw e } catch (_: Exception) { 0 }
                                        if (count > 0) { prefs.edit().putBoolean(unique, true).apply(); saved += count } else failed++
                                        delay(150)
                                    }
                                }
                            }
                        }
                        status = "Finished · $saved saved, $skipped skipped, $failed failed"
                    } catch (_: CancellationException) {
                        status = "Stopped · $saved saved, $skipped skipped, $failed failed"
                    } finally { running = false }
                }
            }) { Text("Start collecting") }
            OutlinedButton(enabled = running, onClick = { job?.cancel() }) { Text("Stop") }
        }
        Spacer(Modifier.height(12.dp))
        if (running) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text(status)
        Text("Saved: $saved   Skipped: $skipped   Failed: $failed")
    }
}
