package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.unit.dp

/** Library now contains only the on-device Gallery. Source browsing remains in Search/Discover. */
@Composable
fun IrisLibraryHub(onGalleryClick: (Int) -> Unit, onShowDetail: (Int) -> Unit) {
    var collector by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Text("Library", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp))
        Text("Your personal visual library", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp))
        TextButton(onClick = { collector = !collector }, modifier = Modifier.padding(horizontal = 12.dp)) { Text(if (collector) "‹ Gallery" else "Auto Collector") }
        Spacer(Modifier.height(8.dp))
        if (collector) IrisCollectorScreen(Modifier.weight(1f)) else IrisGallerySection(Modifier.weight(1f))
    }
}
