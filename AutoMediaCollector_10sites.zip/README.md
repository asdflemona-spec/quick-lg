# Auto Media Collector — Android prototype

## Status
This is a **buildable architecture prototype**, NOT a verified scraper for ten sites. All ten site adapters are present in `SiteRegistry.kt` but **disabled** (`verified=false`, empty `boards`). It will not download anything until site-specific public board URLs are configured and verified. This prevents misleading success claims and accidental broad crawling.

## Five fixed stages
1. Public HTML retrieval + basic media URL discovery (Jsoup).
2. Bounded link discovery on configured public boards.
3. Keyword prefilter (ㅇㅎ/약후/후방/후방주의); **no visual AI classifier yet**.
4. Android WorkManager periodic operation, MediaStore save, URL-hash dedupe.
5. Site registry to extend and verify adapters individually.

## Included candidate sites
DC Inside, FM Korea, Ruliweb, Issuya, Ppomppu, TodayHumor, Inven, Bobaedream, Tistory, TheQoo.

## Limitations / security
- No login, OAuth, paid API, CAPTCHA solving, or access-control bypass.
- No DRM, HLS/DASH reconstruction, or external video provider downloading.
- Site-specific selectors, pagination, canonical media links, robots/terms review, actual end-to-end tests and visual classification are still required.
- No age verification: **do not enable automated sexual-content collection until a reliable exclusion policy for minors and non-consensual material is implemented**.
- Only HTTPS. Avoid untrusted redirect targets. Current prototype disables automatic redirects and has basic hostname checks, not complete DNS rebinding protection.
- Background jobs are inexact due to Android OS restrictions. Default interval 30 minutes.
- At most 40 candidate links and 40 media URLs per board/post, 100 MB per media file.
- Some content types are unsupported. No guarantee that generic HTML extraction works on any listed site.

## Build
Requires JDK 17, Android SDK 35, Gradle 8.9+ (or Android Studio with matching Gradle).
Run `gradle assembleDebug` in the project root. The project intentionally omits a Gradle wrapper JAR; the GitHub Actions workflow can use its installed Gradle.

## GitHub ZIP workflow
Upload **this ZIP as the only ZIP** in the repository. Use the workflow in `.github/workflows/build-apk.yml` in the repository itself (GitHub will not run workflow YAML inside an unextracted ZIP). Workflow finds the project root inside ZIP.
