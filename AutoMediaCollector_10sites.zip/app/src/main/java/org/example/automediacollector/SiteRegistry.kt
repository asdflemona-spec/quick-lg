package org.example.automediacollector

data class Site(val id:String,val host:String,val boards:List<String> = emptyList(),val verified:Boolean=false)

/** Verification gate: add actual PUBLIC board URLs, then enable only after tests. */
object SiteRegistry {
 val sites=listOf(
  Site("dcinside","dcinside.com"),
  Site("fmkorea","fmkorea.com"),
  Site("ruliweb","ruliweb.com"),
  Site("issuya","issuya.com"),
  Site("ppomppu","ppomppu.co.kr"),
  Site("todayhumor","todayhumor.co.kr"),
  Site("inven","inven.co.kr"),
  Site("bobaedream","bobaedream.co.kr"),
  Site("tistory","tistory.com"),
  Site("theqoo","theqoo.net")
 )
}
