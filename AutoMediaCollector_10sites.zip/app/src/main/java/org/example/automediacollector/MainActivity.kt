package org.example.automediacollector

import android.app.Activity
import android.os.Bundle
import android.widget.*
import androidx.work.*
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,40,32,24) }
  val status = TextView(this).apply { text = "10-site prototype • public pages only\nNo login / no API / no paid service\nUnverified site adapters are disabled until tested."; textSize=17f }
  val start = Button(this).apply { text = "Start periodic collection" }
  val once = Button(this).apply { text = "Run once now" }
  val stop = Button(this).apply { text = "Stop" }
  val note = TextView(this).apply { text = "Configure board URLs and mark verified adapters in SiteRegistry.kt. Collection defaults OFF. 15-minute minimum periodic interval; Android may delay runs." }
  layout.addView(status);layout.addView(start);layout.addView(once);layout.addView(stop);layout.addView(note)
  setContentView(layout)
  start.setOnClickListener {
   val req=PeriodicWorkRequestBuilder<CollectorWorker>(30,TimeUnit.MINUTES).setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
   WorkManager.getInstance(this).enqueueUniquePeriodicWork("collector",ExistingPeriodicWorkPolicy.KEEP,req)
   Toast.makeText(this,"Periodic job scheduled",Toast.LENGTH_SHORT).show()
  }
  once.setOnClickListener { WorkManager.getInstance(this).enqueue(OneTimeWorkRequestBuilder<CollectorWorker>().build()) }
  stop.setOnClickListener { WorkManager.getInstance(this).cancelUniqueWork("collector") }
 }
}
