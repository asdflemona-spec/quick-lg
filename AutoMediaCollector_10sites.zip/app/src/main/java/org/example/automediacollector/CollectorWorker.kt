package org.example.automediacollector

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import java.net.URI
import java.net.URL
import java.net.HttpURLConnection
import java.security.MessageDigest
import android.provider.MediaStore
import android.content.ContentValues
import android.os.Environment

class CollectorWorker(ctx:Context, params:WorkerParameters):CoroutineWorker(ctx,params) {
 private val prefs=ctx.getSharedPreferences("seen",Context.MODE_PRIVATE)
 private val keywords=listOf("ㅇㅎ","약후","후방","후방주의")
 override suspend fun doWork():Result=withContext(Dispatchers.IO) {
  try {
   SiteRegistry.sites.filter { it.verified }.forEach { site ->
    site.boards.forEach { board ->
     if (!allowed(board,site.host)) return@forEach
     val page=fetchHtml(board) ?: return@forEach
     // Generic link discovery is intentionally bounded; per-site adapters must be validated.
     val candidates=page.select("a[href]").map { it.absUrl("href") }.filter { allowed(it,site.host) }.distinct().take(40)
     candidates.forEach { postUrl ->
      if (prefs.getBoolean("post:"+postUrl,false)) return@forEach
      val post=fetchHtml(postUrl) ?: return@forEach
      val text=(post.title()+" "+post.body().text()).lowercase()
      if (keywords.none { it in text }) return@forEach
      val media=post.select("img[src],video[src],video source[src]")
       .map { it.absUrl("src") }.filter { allowedMedia(it) }.distinct().take(40)
      var allOk=true
      media.forEach { url -> if (!saveMedia(url)) allOk=false }
      if (media.isNotEmpty() && allOk) prefs.edit().putBoolean("post:"+postUrl,true).apply()
     }
    }
   }
   Result.success()
  } catch (e:Exception) { Result.retry() }
 }
 private fun allowed(url:String,host:String):Boolean=try { val u=URI(url);u.scheme=="https" && (u.host==host || u.host?.endsWith(".$host")==true) } catch (_:Exception){false}
 private fun allowedMedia(url:String):Boolean=try { val u=URI(url);u.scheme=="https" && !u.host.isNullOrBlank() && !isPrivateHost(u.host!!) } catch (_:Exception){false}
 private fun isPrivateHost(host:String):Boolean {
  val h=host.lowercase()
  return h=="localhost" || h.endsWith(".local") || h=="127.0.0.1" || h=="0.0.0.0" || h=="::1" || h.startsWith("10.") || h.startsWith("192.168.") || h.startsWith("169.254.") || h.startsWith("172.16.")
 }
 private fun fetchHtml(url:String)=try { Jsoup.connect(url).userAgent("AutoMediaCollector/0.1 (public-page prototype)").timeout(12000).maxBodySize(2_000_000).get() } catch (_:Exception){null}
 private fun saveMedia(url:String):Boolean {
  if (!allowedMedia(url)) return false
  val hash=MessageDigest.getInstance("SHA-256").digest(url.toByteArray()).joinToString(""){ "%02x".format(it) }
  if (prefs.getBoolean("media:$hash",false)) return true
  var conn:HttpURLConnection?=null
  return try {
   conn=URL(url).openConnection() as HttpURLConnection
   conn.connectTimeout=12000;conn.readTimeout=20000;conn.instanceFollowRedirects=false
   if (conn.responseCode!=200) return false
   val mime=conn.contentType?.substringBefore(';')?.lowercase() ?: return false
   if (!(mime.startsWith("image/") || mime.startsWith("video/"))) return false
   val extension=when(mime){"image/jpeg"->"jpg";"image/png"->"png";"image/gif"->"gif";"image/webp"->"webp";"video/mp4"->"mp4";"video/webm"->"webm";else->return false}
   val collection=if(mime.startsWith("image/")) MediaStore.Images.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
   val values=ContentValues().apply {put(MediaStore.MediaColumns.DISPLAY_NAME,"media_$hash.$extension");put(MediaStore.MediaColumns.MIME_TYPE,mime);put(MediaStore.MediaColumns.RELATIVE_PATH,(if(mime.startsWith("image/")) Environment.DIRECTORY_PICTURES else Environment.DIRECTORY_MOVIES)+"/AutoMediaCollector");put(MediaStore.MediaColumns.IS_PENDING,1)}
   val resolver=applicationContext.contentResolver
   val item=resolver.insert(collection,values) ?: return false
   try {
    resolver.openOutputStream(item)?.use { out ->
     conn!!.inputStream.use { input ->
      val buffer=ByteArray(8192);var total=0L
      while(true){val n=input.read(buffer);if(n<0)break;total+=n;if(total>100L*1024*1024)throw IllegalStateException("File too large");out.write(buffer,0,n)}
     }
    } ?: throw IllegalStateException("Cannot open destination")
    resolver.update(item,ContentValues().apply{put(MediaStore.MediaColumns.IS_PENDING,0)},null,null)
    prefs.edit().putBoolean("media:$hash",true).apply();true
   } catch(e:Exception){resolver.delete(item,null,null);false}
  } catch (_:Exception){false} finally {conn?.disconnect()}
 }
}
