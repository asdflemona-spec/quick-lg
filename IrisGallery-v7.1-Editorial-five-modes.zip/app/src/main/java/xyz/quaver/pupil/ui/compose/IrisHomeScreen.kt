/*
 * Iris Gallery fork of Pupil.
 * Pupil portions remain licensed under GPLv3; see app/LICENSE and FORK_NOTICE_KO.md.
 */
package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import xyz.quaver.pupil.source.GgoorrSource
import xyz.quaver.pupil.source.DcinsideSource
import xyz.quaver.pupil.source.BobaedreamSource
import xyz.quaver.pupil.source.ContentSource
import xyz.quaver.pupil.source.SourceDetail
import xyz.quaver.pupil.source.SourceItem
import xyz.quaver.pupil.ui.viewmodel.SearchViewModel
import xyz.quaver.pupil.util.IrisSourceActions

enum class IrisHomeSource(val label: String) { HITOMI("Hitomi"), GGOORR("Ggoorr"), BOBA_NSFW("Boba NSFW"), BOBA_GIRL("Boba Girl"), DC_GIRL("DC Girl"), DC_BEST("DC Best ㅇㅎ") }

@Composable
fun IrisHomeScreen(
    onGalleryClick: (Int) -> Unit,
    onShowDetail: (Int) -> Unit,
    searchViewModel: SearchViewModel,
    onViewerActiveChanged: (Boolean) -> Unit = {},
) {
    var selected by remember { mutableStateOf(IrisHomeSource.HITOMI) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
            Text("Search", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Search your sources. Source choice is a filter, not the destination.",
                style = MaterialTheme.typography.bodySmall,
            )
            Spacer(Modifier.height(8.dp))
            LazyRow {
                item { FilterChip(
                    selected = selected == IrisHomeSource.HITOMI,
                    onClick = { selected = IrisHomeSource.HITOMI },
                    label = { Text("Hitomi") },
                ) }
                item { Spacer(Modifier.size(8.dp)) }
                item { FilterChip(
                    selected = selected == IrisHomeSource.GGOORR,
                    onClick = { selected = IrisHomeSource.GGOORR },
                    label = { Text("Ggoorr") },
                ) }
                item { Spacer(Modifier.size(8.dp)) }
                item { FilterChip(selected == IrisHomeSource.BOBA_NSFW, { selected = IrisHomeSource.BOBA_NSFW }, { Text("Boba NSFW") }) }
                item { Spacer(Modifier.size(8.dp)) }
                item { FilterChip(selected == IrisHomeSource.BOBA_GIRL, { selected = IrisHomeSource.BOBA_GIRL }, { Text("Boba Girl") }) }
                item { Spacer(Modifier.size(8.dp)) }
                item { FilterChip(selected == IrisHomeSource.DC_GIRL, { selected = IrisHomeSource.DC_GIRL }, { Text("DC Girl") }) }
                item { Spacer(Modifier.size(8.dp)) }
                item { FilterChip(selected == IrisHomeSource.DC_BEST, { selected = IrisHomeSource.DC_BEST }, { Text("DC Best ㅇㅎ") }) }
            }
        }

        when (selected) {
            IrisHomeSource.HITOMI -> SearchScreen(
                modifier = Modifier.weight(1f),
                onGalleryClick = onGalleryClick,
                onShowDetail = onShowDetail,
                viewModel = searchViewModel,
            )
            IrisHomeSource.GGOORR -> GgoorrSourceScreen(Modifier.weight(1f), onViewerActiveChanged)
            IrisHomeSource.BOBA_NSFW -> GgoorrSourceScreen(Modifier.weight(1f), onViewerActiveChanged, BobaedreamSource("nsfw"))
            IrisHomeSource.BOBA_GIRL -> GgoorrSourceScreen(Modifier.weight(1f), onViewerActiveChanged, BobaedreamSource("girl"))
            IrisHomeSource.DC_GIRL -> GgoorrSourceScreen(Modifier.weight(1f), onViewerActiveChanged, DcinsideSource("duwk"))
            IrisHomeSource.DC_BEST -> GgoorrSourceScreen(Modifier.weight(1f), onViewerActiveChanged, DcinsideSource("dcbest"))
        }
    }
}


@Composable
private fun GgoorrSourceScreen(
    modifier: Modifier = Modifier,
    onViewerActiveChanged: (Boolean) -> Unit = {},
    provider: ContentSource = remember { GgoorrSource() },
) {
    val source = provider
    val headers = when (source) {
        is GgoorrSource -> source.requestHeaders
        is BobaedreamSource -> source.requestHeaders
        is DcinsideSource -> source.requestHeaders
        else -> emptyMap()
    }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var query by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<SourceItem>>(emptyList()) }
    var nextPage by remember { mutableStateOf<Int?>(null) }
    var detail by remember { mutableStateOf<SourceDetail?>(null) }
    var loading by remember { mutableStateOf(false) }
    var loadingMore by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    var saved by remember { mutableStateOf(false) }

    fun load(page: Int, append: Boolean) {
        if (loading || loadingMore) return
        scope.launch {
            if (append) loadingMore = true else loading = true
            error = null
            if (!append) detail = null
            try {
                val result = source.search(query, page)
                if (append) {
                    // Notice/sticky rows can repeat between board pages. Keep one Iris item per source ID.
                    items = (items + result.items).distinctBy { "${it.sourceId}:${it.remoteId}" }
                } else {
                    items = result.items.distinctBy { "${it.sourceId}:${it.remoteId}" }
                }
                nextPage = result.nextPage
            } catch (t: Throwable) {
                error = t.message ?: t.javaClass.simpleName
            } finally {
                if (append) loadingMore = false else loading = false
            }
        }
    }

    fun search() = load(page = 0, append = false)
    fun loadMore() = nextPage?.let { load(page = it, append = true) }

    LaunchedEffect(Unit) { search() }
    LaunchedEffect(detail) { onViewerActiveChanged(detail != null) }
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose { onViewerActiveChanged(false) }
    }

    // Incremental loading: when the user gets near the end, request the next real Ggoorr board page.
    LaunchedEffect(listState) {
        snapshotFlow {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
            last to listState.layoutInfo.totalItemsCount
        }.distinctUntilChanged().collect { (last, total) ->
            if (total > 0 && last >= total - 5 && !loading && !loadingMore && nextPage != null && detail == null) {
                loadMore()
            }
        }
    }

    val current = detail
    if (current != null) {
        IrisViewer(
            detail = current,
            headers = headers,
            saved = saved,
            onBack = { detail = null },
            onToggleSaved = { saved = IrisSourceActions.toggleSaved(context, current) },
            onDownload = { scope.launch { IrisSourceActions.download(context, current, headers) } },
            onShare = { IrisSourceActions.share(context, current) },
            onOriginal = { IrisSourceActions.openOriginal(context, current.item.pageUrl) },
        )
        return
    }

    Column(modifier.padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                label = { Text("Filter ${source.displayName} page") },
                singleLine = true,
            )
            Button(onClick = { search() }, modifier = Modifier.padding(start = 8.dp)) { Text("Go") }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        error?.let { Text("Source error: $it", modifier = Modifier.padding(vertical = 8.dp)) }

        LazyColumn(Modifier.fillMaxSize(), state = listState) {
            items(items, key = { it.remoteId }) { item ->
                Row(
                    Modifier.fillMaxWidth().clickable {
                        scope.launch {
                            loading = true
                            error = null
                            try {
                                detail = source.detail(item.remoteId)
                                detail?.let {
                                    IrisSourceActions.recordHistory(context, it)
                                    saved = IrisSourceActions.isSaved(context, it)
                                }
                            } catch (t: Throwable) {
                                error = t.message ?: t.javaClass.simpleName
                            } finally { loading = false }
                        }
                    }.padding(vertical = 8.dp)
                ) {
                    RemoteImage(item.thumbnailUrl, Modifier.size(84.dp), item.title, headers = headers)
                    Column(Modifier.padding(start = 12.dp)) {
                        Text(item.title, style = MaterialTheme.typography.titleMedium)
                        Text(source.displayName, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            if (loadingMore) {
                item { LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 12.dp)) }
            }
            if (items.isNotEmpty() && nextPage == null) {
                item { Text("End of results", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(16.dp)) }
            }
        }
    }
}

