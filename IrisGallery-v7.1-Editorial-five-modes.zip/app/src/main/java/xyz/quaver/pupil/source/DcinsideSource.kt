package xyz.quaver.pupil.source

import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.isSuccess
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import xyz.quaver.pupil.client
import java.io.IOException
import java.net.URI
import java.util.concurrent.ConcurrentHashMap

/** Separate public DCInside feeds; keeps search parameters fixed to the supplied URLs. */
class DcinsideSource(private val board: String) : ContentSource {
    init { require(board == "duwk" || board == "dcbest") }
    override val id = "dcinside_$board"
    override val displayName = if (board == "duwk") "DC Girl" else "DC Best ㅇㅎ"
    override val maturity = SourceMaturity.ADULT
    override val availability = SourceAvailability.READY
    override val capabilities = setOf(SourceCapability.BROWSE, SourceCapability.DETAIL,
        SourceCapability.MULTI_IMAGE, SourceCapability.DOWNLOAD)
    private val base = "https://m.dcinside.com"
    private val cache = ConcurrentHashMap<String, String>()
    private val permits = Semaphore(4)
    val requestHeaders = mapOf(
        "Referer" to "https://m.dcinside.com/",
        "User-Agent" to "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
    )
    private fun listingUrl(page: Int): String {
        val params = if (board == "duwk") "recommend=1" else
            "s_type=subject_m&serval=%E3%85%87%E3%85%8E&recommend=&headid="
        return "$base/board/$board?$params&page=${page + 1}"
    }
    private suspend fun document(url: String): Document {
        val response = client.get(url) { requestHeaders.forEach { (k, v) -> header(k, v) } }
        if (!response.status.isSuccess()) throw IOException("DCInside HTTP ${response.status.value}")
        return Jsoup.parse(response.bodyAsText(), url)
    }
    override suspend fun search(query: String, page: Int): SourcePage {
        require(page >= 0)
        val doc = document(listingUrl(page))
        val seen = hashSetOf<String>()
        val rows = doc.select("tr.ub-content, tr[data-no], li[data-no], .gall-detail-lst li, .gall_list tr")
        val items = rows.mapNotNull { row ->
            val a = row.selectFirst("a[href*=/board/view/], a[href*=/mgallery/board/view/], a[href*=/board/duwk/], a[href*=/board/dcbest/]")
                ?: return@mapNotNull null
            val url = a.absUrl("href")
            val parsed = parsePost(url) ?: return@mapNotNull null
            if (parsed.first != board || !seen.add(parsed.second)) return@mapNotNull null
            val title = a.text().trim().ifBlank { a.attr("title").trim() }
            if (title.isBlank() || (query.isNotBlank() && !title.contains(query, true))) return@mapNotNull null
            val thumbnail = row.selectFirst("img[data-src], img[src]")?.let(::imageUrl)
            SourceItem(id, parsed.second, title, thumbnail, url)
        }
        val enriched = coroutineScope {
            items.map { item -> async {
                val cover = cache[item.remoteId] ?: item.thumbnailUrl ?: permits.withPermit {
                    runCatching { detail(item.remoteId).imageUrls.firstOrNull() }.getOrNull()
                }
                if (cover != null) cache[item.remoteId] = cover
                item.copy(thumbnailUrl = cover)
            } }.awaitAll()
        }
        return SourcePage(enriched, if (items.isNotEmpty()) page + 1 else null)
    }
    override suspend fun detail(remoteId: String): SourceDetail {
        require(remoteId.matches(Regex("[0-9]+")))
        val url = "$base/board/$board/$remoteId"
        val doc = document(url)
        val title = doc.selectFirst(".title_subject, .gallview_head .title, h3.title, h1")?.text()?.trim()
            ?.takeIf { it.isNotBlank() } ?: doc.title()
        val root = doc.selectFirst(".write_div, .writing_view_box, .view_content_wrap, .gallview_contents, .thum-txtin, #memo")
            ?: doc.body()
        val images = linkedSetOf<String>()
        root.select("img, video, source, a[href]").forEach { el ->
            val attrs = if (el.normalName() == "a") listOf("href") else
                listOf("data-original", "data-src", "data-lazy-src", "data-url", "src")
            attrs.forEach { attr -> mediaUrl(el, attr)?.let(images::add) }
        }
        val result = images.toList()
        return SourceDetail(SourceItem(id, remoteId, title, result.firstOrNull(), url), result)
    }
    private fun parsePost(url: String): Pair<String, String>? {
        val uri = runCatching { URI(url) }.getOrNull() ?: return null
        val path = uri.path.orEmpty()
        val mobile = Regex("^/board/(duwk|dcbest)/(\\d+)(?:/|$)").find(path)
        if (mobile != null) return mobile.groupValues[1] to mobile.groupValues[2]
        if (!path.contains("/board/view")) return null
        val query = uri.rawQuery.orEmpty().split('&').mapNotNull {
            val k = it.substringBefore('='); val v = it.substringAfter('=', "")
            if (k == "id" || k == "no") k to v else null
        }.toMap()
        val id = query["id"] ?: return null
        val no = query["no"] ?: return null
        return if (no.matches(Regex("\\d+"))) id to no else null
    }
    private fun imageUrl(el: Element): String? = listOf("data-original", "data-src", "src")
        .firstNotNullOfOrNull { mediaUrl(el, it) }
    private fun mediaUrl(el: Element, attr: String): String? {
        val raw = el.attr(attr).trim().replace("&amp;", "&")
        if (raw.isBlank() || raw.startsWith("data:") || raw.startsWith("javascript:")) return null
        val uri = runCatching { URI(el.baseUri()).resolve(raw) }.getOrNull() ?: return null
        if (uri.scheme !in listOf("https", "http")) return null
        val url = uri.toString()
        val path = uri.path.orEmpty().lowercase()
        if (listOf("icon", "logo", "avatar", "btn_", "loading", "blank", "search", "dccon")
                .any { path.substringAfterLast('/').contains(it) }) return null
        return if (listOf(".jpg", ".jpeg", ".png", ".gif", ".webp", ".avif", ".mp4", ".webm")
                .any { path.endsWith(it) } || path.contains("/viewimage") || path.contains("/download/")) url else null
    }
}
