package xyz.quaver.pupil.source

object SourceRegistry {
    val sources: List<ContentSource> = listOf(
        HitomiSource(),
        GgoorrSource(),
        BobaedreamSource("nsfw"),
        BobaedreamSource("girl"),
        DcinsideSource("duwk"),
        DcinsideSource("dcbest"),
    )

    fun byId(id: String): ContentSource? = sources.firstOrNull { it.id == id }
    val ready: List<ContentSource> get() = sources.filter { it.availability == SourceAvailability.READY }
}
