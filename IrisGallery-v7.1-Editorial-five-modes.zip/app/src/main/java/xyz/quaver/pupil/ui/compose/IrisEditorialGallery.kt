package xyz.quaver.pupil.ui.compose

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import xyz.quaver.pupil.util.IrisGalleryMedia

/** Five distinct, purely presentational local-media lenses. Never edits source files. */
@Composable
fun IrisEditorialGallery(
    media: List<IrisGalleryMedia>, mode: IrisGallerySkin,
    open: (IrisGalleryMedia) -> Unit, modifier: Modifier = Modifier
) {
    val photos = remember(media) { media.filterNot { it.isVideo } }
    if (photos.isEmpty()) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No photos in your gallery") }
        return
    }
    when (mode) {
        IrisGallerySkin.FASHION -> FashionGallery(photos, open, modifier)
        IrisGallerySkin.ROMANCE -> RomanceGallery(photos, open, modifier)
        IrisGallerySkin.DATING -> DatingGallery(photos, open, modifier)
        IrisGallerySkin.PINUP -> PinupGallery(photos, open, modifier)
        IrisGallerySkin.BLIND -> BlindBoxGallery(photos, open, modifier)
        else -> Unit
    }
}

@Composable
private fun Cover(photo: IrisGalleryMedia, modifier: Modifier = Modifier, scale: ContentScale = ContentScale.Crop) {
    AsyncImage(model = photo.uri, contentDescription = photo.name, modifier = modifier, contentScale = scale)
}

@Composable
private fun FashionGallery(photos: List<IrisGalleryMedia>, open: (IrisGalleryMedia) -> Unit, modifier: Modifier) {
    LazyColumn(modifier.fillMaxSize().background(Color(0xFFF6F0EA)), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Column(Modifier.padding(22.dp)) {
                Text("ATELIER", fontSize = 36.sp, fontWeight = FontWeight.Light, letterSpacing = 7.sp, color = Color(0xFF25201E))
                Text("FASHION  /  INTIMATES  /  PERSONAL ARCHIVE", fontSize = 10.sp, letterSpacing = 2.sp, color = Color.DarkGray)
            }
        }
        items(photos.chunked(3)) { group ->
            val lead = group.first()
            Box(Modifier.fillMaxWidth().height(390.dp).padding(horizontal = 14.dp).clip(RoundedCornerShape(3.dp)).clickable { open(lead) }) {
                Cover(lead, Modifier.fillMaxSize())
                Text("THE EDIT", Modifier.align(Alignment.BottomStart).padding(18.dp).background(Color.Black.copy(alpha = .42f)).padding(9.dp), color = Color.White, letterSpacing = 3.sp)
            }
            Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                group.drop(1).forEach { photo ->
                    Cover(photo, Modifier.weight(1f).height(150.dp).clip(RoundedCornerShape(3.dp)).clickable { open(photo) })
                }
            }
            HorizontalDivider(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), color = Color.LightGray)
        }
    }
}

@Composable
private fun RomanceGallery(photos: List<IrisGalleryMedia>, open: (IrisGalleryMedia) -> Unit, modifier: Modifier) {
    var index by remember(photos) { mutableIntStateOf(0) }
    val photo = photos[index % photos.size]
    Column(modifier.fillMaxSize().background(Color(0xFF10101A)).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("CINEMA OF MOMENTS", color = Color(0xFFF4D8D6), letterSpacing = 4.sp, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().weight(1f).background(Color.Black).clickable { open(photo) }, contentAlignment = Alignment.Center) {
            Cover(photo, Modifier.fillMaxWidth().aspectRatio(1.35f), ContentScale.Fit)
        }
        Spacer(Modifier.height(12.dp))
        Text("SCENE ${(index % photos.size) + 1} / ${photos.size}", color = Color(0xFFD6B5AF), letterSpacing = 3.sp, fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            OutlinedButton(onClick = { index = (index - 1 + photos.size) % photos.size }) { Text("Previous") }
            Button(onClick = { index = (index + 1) % photos.size }) { Text("Next scene") }
        }
    }
}

@Composable
private fun DatingGallery(photos: List<IrisGalleryMedia>, open: (IrisGalleryMedia) -> Unit, modifier: Modifier) {
    var index by remember(photos) { mutableIntStateOf(0) }
    var liked by remember { mutableStateOf(setOf<String>()) }
    val photo = photos[index % photos.size]
    Column(modifier.fillMaxSize().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("DISCOVER", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Choose photos you enjoy — no personal profiles", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth().weight(1f).clickable { open(photo) }, shape = RoundedCornerShape(24.dp)) {
            Box(Modifier.fillMaxSize()) {
                Cover(photo, Modifier.fillMaxSize())
                Text("PHOTO ${(index % photos.size) + 1}", Modifier.align(Alignment.BottomStart).background(Color.Black.copy(alpha = .5f)).padding(12.dp), color = Color.White)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { index++ }) { Text("Pass") }
            Button(onClick = { liked = liked + photo.uri; index++ }) { Text("♥ Like") }
            TextButton(onClick = { open(photo) }) { Text("View") }
        }
        Text("Liked this session: ${liked.size}", style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun PinupGallery(photos: List<IrisGalleryMedia>, open: (IrisGalleryMedia) -> Unit, modifier: Modifier) {
    LazyColumn(modifier.fillMaxSize().background(Color(0xFFFFF4DF)), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item { Text("THE PHOTO REVUE", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Color(0xFF9E292E), letterSpacing = 2.sp) }
        items(photos.chunked(2)) { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEachIndexed { i, photo ->
                    Column(Modifier.weight(1f).background(Color.White, RoundedCornerShape(8.dp)).padding(7.dp).clickable { open(photo) }) {
                        Cover(photo, Modifier.fillMaxWidth().aspectRatio(if (i == 0) .72f else .83f))
                        Text(if (i == 0) "PORTRAIT" else "FEATURE", Modifier.fillMaxWidth().padding(top = 8.dp), textAlign = TextAlign.Center, color = Color(0xFF9E292E), fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun BlindBoxGallery(photos: List<IrisGalleryMedia>, open: (IrisGalleryMedia) -> Unit, modifier: Modifier) {
    var order by remember(photos) { mutableStateOf(photos.shuffled()) }
    var index by remember(photos) { mutableIntStateOf(0) }
    var revealed by remember(photos) { mutableStateOf(false) }
    val photo = order[index % order.size]
    Column(modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("MYSTERY PHOTO BOX", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Open a box to discover a random photo", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(18.dp))
        Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(24.dp)).background(Color(0xFF34304E)).clickable { if (revealed) open(photo) else revealed = true }, contentAlignment = Alignment.Center) {
            if (revealed) Cover(photo, Modifier.fillMaxSize())
            else Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("?", fontSize = 96.sp, color = Color.White, fontWeight = FontWeight.Black)
                Text("TAP TO UNBOX", color = Color.White, letterSpacing = 3.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { if (revealed) { index++; revealed = false } else revealed = true }) { Text(if (revealed) "Next box" else "Unbox") }
            OutlinedButton(onClick = { order = photos.shuffled(); index = 0; revealed = false }) { Text("Reshuffle") }
            if (revealed) TextButton(onClick = { open(photo) }) { Text("Open") }
        }
    }
}
