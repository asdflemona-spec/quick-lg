package xyz.quaver.pupil.source

import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.isSuccess
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import xyz.quaver.pupil.client
import java.io.IOException
import java.net.URI

/** Independent public-board adapter; never mixes post IDs between the two boards. */
class BobaedreamSource(private val board: String) : ContentSource {
    init { require(board == "nsfw" || board == "girl") }
    override val id = "bobaedream_$board"
    override val displayName = if (board == "nsfw") "Bobaedream NSFW" else "Bobaedream Girl"
    override val maturity = if (board == "nsfw") SourceMaturity.ADULT else SourceMaturity.GENERAL
    override val availability = SourceAvailability.READY
    override val capabilities = setOf(SourceCapability.BROWSE, SourceCapability.DETAIL,
        SourceCapability.MULTI_IMAGE, SourceCapability.VIDEO, SourceCapability.DOWNLOAD)
    private val base = "https://m.bobaedream.co.kr"
    private val boardUrl = "$base/board/new_writing/$board"
    val requestHeaders = mapOf("Referer" to "$base/", "User-Agent" to
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")

    private suspend fun document(url: String): Document {
        val response = client.get(url) { requestHeaders.forEach { (k, v) -> header(k, v) } }
        if (!response.status.isSuccess()) throw IOException("Bobaedream HTTP ${response.status.value}")
        return Jsoup.parse(response.bodyAsText(), url)
    }

    override suspend fun search(query: String, page: Int): SourcePage {
        require(page >= 0)
        // Search is a local title filter of the fetched board page, not a site-wide search.
        val doc = document(if (page == 0) boardUrl else "$boardUrl/${page + 1}")
        val seen = hashSetOf<String>()
        val items = doc.select("a[href*=/board/bbs_view/]").mapNotNull { a ->
            val url = a.absUrl("href")
            val match = Regex("/board/bbs_view/(nsfw|girl)/(\\d+)(?:/|$)").find(URI(url).path ?: "")
                ?: return@mapNotNull null
            if (match.groupValues[1] != board) return@mapNotNull null
            val remoteId = match.groupValues[2]
            if (!seen.add(remoteId)) return@mapNotNull null
            val title = a.text().trim().ifBlank { a.attr("title").trim() }
            if (title.isBlank() || (query.isNotBlank() && !title.contains(query, ignoreCase = true))) return@mapNotNull null
            val thumb = a.closest("li, tr, .list, .item")?.selectFirst("img")?.let(::mediaUrl)
            SourceItem(id, remoteId, title, thumb, url)
        }
        val hasNext = doc.select("a[href]").any { a ->
            val path = runCatching { URI(a.absUrl("href")).path }.getOrNull()
            path == "/board/new_writing/$board/${page + 2}"
        }
        return SourcePage(items, if (hasNext) page + 1 else null)
    }

    override suspend fun detail(remoteId: String): SourceDetail {
        require(remoteId.matches(Regex("[0-9]+")))
        val url = "$base/board/bbs_view/$board/$remoteId"
        val doc = document(url)
        val title = doc.selectFirst("h3, h2, h1")?.text()?.trim()?.takeIf { it.isNotBlank() } ?: doc.title()
        val scope = doc.selectFirst(".bodyCont, .board-view, .view_content, .viewContent, .article_view, .content_view, #bodyContent")
            ?: doc.body()
        val media = linkedSetOf<String>()
        scope.select("img, video, source").forEach { e ->
            listOf("data-original", "data-src", "data-lazy-src", "src").forEach { attr ->
                mediaUrl(e, attr)?.let(media::add)
            }
        }
        scope.select("a[href]").forEach { e ->
            mediaUrl(e, "href")?.takeIf(::looksLikeMedia)?.let(media::add)
        }
        val filtered = media.filterNot { url ->
            listOf("logo", "icon", "avatar", "emoji", "banner", "profile").any { url.contains(it, true) }
        }
        return SourceDetail(SourceItem(id, remoteId, title, filtered.firstOrNull(), url), filtered)
    }

    private fun mediaUrl(e: Element, attr: String = "src"): String? {
        val raw = e.attr(attr).trim()
        if (raw.isBlank() || raw.startsWith("data:") || raw.startsWith("javascript:")) return null
        return runCatching { URI(base).resolve(raw).toString() }.getOrNull()
    }
    private fun looksLikeMedia(url: String): Boolean =
        listOf(".jpg", ".jpeg", ".png", ".gif", ".webp", ".mp4", ".webm", ".mov")
            .any { url.substringBefore('?').lowercase().endsWith(it) }
}
