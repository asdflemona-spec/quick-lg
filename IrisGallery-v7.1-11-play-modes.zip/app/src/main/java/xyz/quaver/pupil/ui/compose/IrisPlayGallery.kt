package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import xyz.quaver.pupil.util.IrisGalleryMedia
import kotlin.math.absoluteValue

/** Presentation-only lenses: all photos are read from the existing MediaStore index. */
@Composable fun IrisPlayGallery(media: List<IrisGalleryMedia>, mode: IrisGallerySkin, open: (IrisGalleryMedia)->Unit, modifier: Modifier = Modifier) {
    val photos = remember(media) { media.filter { !it.isVideo } }
    var nonce by remember(mode) { mutableIntStateOf(0) }
    val shuffled = remember(photos, nonce) { photos.shuffled(kotlin.random.Random(nonce + 421)) }
    if (photos.isEmpty()) { Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Add photos to play") }; return }
    when(mode) {
        IrisGallerySkin.CARDS -> LazyVerticalGrid(GridCells.Fixed(3),modifier,contentPadding=PaddingValues(8.dp),horizontalArrangement=Arrangement.spacedBy(7.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
            items(photos.size) { i -> PhotoTile(photos[i],open,Modifier.aspectRatio(.69f),"#${i+1}",Color(0xFFDAAD50)) }
        }
        IrisGallerySkin.MUSEUM -> LazyColumn(modifier.background(Color(0xFFDDD4C5)),contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(26.dp)) {
            items(photos) { x -> Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.fillMaxWidth()) { PhotoTile(x,open,Modifier.fillMaxWidth().height(290.dp).padding(horizontal=18.dp),"EXHIBIT",Color(0xFF6A503C)); Text(x.name.take(38),color=Color.DarkGray) } }
        }
        IrisGallerySkin.SCRAPBOOK -> LazyVerticalGrid(GridCells.Fixed(2),modifier.background(Color(0xFFF3E9D8)),contentPadding=PaddingValues(12.dp),horizontalArrangement=Arrangement.spacedBy(10.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
            items(photos.size) { i -> PhotoTile(photos[i],open,Modifier.rotate(if(i%2==0) -3f else 4f).aspectRatio(.78f),"✦  ${i+1}",Color(0xFFF9F3E8)) }
        }
        IrisGallerySkin.FILM -> LazyColumn(modifier.background(Color(0xFF151515)),contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            items(photos.size) { i -> Column { Text("▪   ▪   ▪   ▪   ▪   ▪   ▪",color=Color.White); PhotoTile(photos[i],open,Modifier.fillMaxWidth().height(260.dp),"FRAME ${i+1}",Color.DarkGray); Text("▪   ▪   ▪   ▪   ▪   ▪   ▪",color=Color.White) } }
        }
        IrisGallerySkin.SLOT -> Column(modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
            Text("PHOTO SLOT",style=MaterialTheme.typography.headlineMedium); Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth().padding(8.dp),horizontalArrangement=Arrangement.spacedBy(5.dp)) { repeat(3) { i -> val x=shuffled[(i+nonce*3).mod(shuffled.size)]; PhotoTile(x,open,Modifier.weight(1f).height(210.dp),"★",Color(0xFF9A752D)) } }
            Button(onClick={nonce++}) { Text("SPIN") }
        }
        IrisGallerySkin.CABINET -> LazyVerticalGrid(GridCells.Fixed(2),modifier,contentPadding=PaddingValues(10.dp),horizontalArrangement=Arrangement.spacedBy(10.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            items(photos.chunked(6).size) { group -> var expanded by remember { mutableStateOf(false) }; Column { Card(onClick={expanded=!expanded},colors=CardDefaults.cardColors(containerColor=Color(0xFF79583F))) { Box(Modifier.fillMaxWidth().height(105.dp),contentAlignment=Alignment.Center){Text(if(expanded) "▼ DRAWER ${group+1}" else "▣ DRAWER ${group+1}",color=Color.White)} }; if(expanded) photos.drop(group*6).take(6).forEach { PhotoTile(it,open,Modifier.fillMaxWidth().height(120.dp),"",Color.Gray) } } }
        }
        IrisGallerySkin.MYSTERY -> LazyVerticalGrid(GridCells.Fixed(3),modifier,contentPadding=PaddingValues(8.dp),horizontalArrangement=Arrangement.spacedBy(7.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
            items(shuffled.size) { i -> var flipped by remember(nonce) { mutableStateOf(false) }; Card(onClick={flipped=true},modifier=Modifier.aspectRatio(.7f)) { if(flipped) PhotoTile(shuffled[i],open,Modifier.fillMaxSize(),"",Color.Gray) else Box(Modifier.fillMaxSize().background(Color(0xFF374C66)),contentAlignment=Alignment.Center){Text("?",color=Color.White,style=MaterialTheme.typography.headlineLarge)} } }
        }
        IrisGallerySkin.STARS -> Box(modifier.fillMaxSize().background(Color(0xFF08152B))) { LazyVerticalGrid(GridCells.Fixed(4),Modifier.fillMaxSize(),contentPadding=PaddingValues(12.dp),horizontalArrangement=Arrangement.spacedBy(12.dp),verticalArrangement=Arrangement.spacedBy(24.dp)) { items(photos.size) { i -> PhotoTile(photos[i],open,Modifier.aspectRatio(1f).padding(if(i%3==0) 0.dp else 7.dp),"✧",Color(0xFF253B61)) } } }
        IrisGallerySkin.TABLE -> LazyVerticalGrid(GridCells.Fixed(2),modifier.background(Color(0xFF8A694B)),contentPadding=PaddingValues(16.dp),horizontalArrangement=Arrangement.spacedBy(9.dp),verticalArrangement=Arrangement.spacedBy(20.dp)) {
            items(shuffled.size) { i -> PhotoTile(shuffled[i],open,Modifier.rotate(if(i%2==0) -7f else 6f).aspectRatio(.83f),"${i+1}",Color.White) }
        }
        IrisGallerySkin.PUZZLE -> PuzzleGallery(photos,modifier,open)
        IrisGallerySkin.DUEL -> PhotoDuel(photos,modifier,open)
        else -> Unit
    }
}

@Composable private fun PhotoTile(x:IrisGalleryMedia,open:(IrisGalleryMedia)->Unit,modifier:Modifier,label:String,border:Color) {
    Card(modifier.clickable { open(x) },shape=RoundedCornerShape(7.dp),border=BorderStroke(4.dp,border)) {
        Box { AsyncImage(model=x.uri,contentDescription=x.name,modifier=Modifier.fillMaxSize(),contentScale=ContentScale.Crop); if(label.isNotBlank()) Text(label,Modifier.align(Alignment.BottomStart).background(Color.Black.copy(alpha=.65f)).padding(4.dp),color=Color.White) }
    }
}

@Composable private fun PuzzleGallery(photos:List<IrisGalleryMedia>,modifier:Modifier,open:(IrisGalleryMedia)->Unit) {
    var index by remember { mutableIntStateOf(0) }; var revealed by remember(index) { mutableStateOf(setOf<Int>()) }
    val x=photos[index.mod(photos.size)]
    Column(modifier.padding(12.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        Text("Reveal the picture · ${revealed.size}/9",style=MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().aspectRatio(1f)) {
            AsyncImage(x.uri,x.name,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
            Column(Modifier.fillMaxSize()) { repeat(3) { r -> Row(Modifier.weight(1f)) { repeat(3) { c -> val n=r*3+c; Box(Modifier.weight(1f).fillMaxHeight().padding(1.dp).background(if(n in revealed) Color.Transparent else Color(0xFF38455D)).clickable { revealed=revealed+n },contentAlignment=Alignment.Center) { if(n !in revealed) Text("${n+1}",color=Color.White) } } } } }
        }
        Row { TextButton(onClick={revealed=(0..8).toSet()}){Text("Reveal all")}; Button(onClick={index++}){Text("Next photo")}; TextButton(onClick={open(x)}){Text("Open")}}
    }
}

private data class DuelCard(val media:IrisGalleryMedia,val atk:Int,val def:Int)
private fun makeCard(x:IrisGalleryMedia):DuelCard { val h=x.uri.hashCode().toLong().absoluteValue; return DuelCard(x,500+(h%21).toInt()*100,500+((h/23)%21).toInt()*100) }
@Composable private fun PhotoDuel(photos:List<IrisGalleryMedia>,modifier:Modifier,open:(IrisGalleryMedia)->Unit) {
    val deck=remember(photos){photos.distinctBy{it.uri}.take(20).map(::makeCard)}
    var turn by remember { mutableIntStateOf(0) }; var playerLp by remember { mutableIntStateOf(4000) }; var cpuLp by remember { mutableIntStateOf(4000) }
    var selected by remember { mutableIntStateOf(-1) }; var played by remember { mutableStateOf<DuelCard?>(null) }
    val hand=remember(deck,turn){if(deck.isEmpty()) emptyList() else (0 until minOf(5,deck.size)).map{deck[(turn*5+it)%deck.size]}}
    Column(modifier.verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("PHOTO DUEL",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Text("CPU LP $cpuLp     ·     YOUR LP $playerLp     ·     TURN ${turn+1}")
        if(deck.size<5) { Text("At least 5 photos required");return@Column }
        val cpu=deck[(turn*7+3)%deck.size]
        Text("CPU MONSTER · ATK ${cpu.atk} / DEF ${cpu.def}")
        PhotoTile(cpu.media,open,Modifier.fillMaxWidth().height(160.dp),"CPU",Color.Red)
        HorizontalDivider()
        Text("YOUR FIELD")
        played?.let { PhotoTile(it.media,open,Modifier.fillMaxWidth().height(150.dp),"ATK ${it.atk}",Color(0xFFBB9B49)) } ?: Text("Select a card, then summon")
        Text("HAND · choose one")
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) { hand.forEachIndexed { i,c -> Column(Modifier.width(105.dp)) { PhotoTile(c.media,{selected=i},Modifier.fillMaxWidth().height(115.dp),"ATK ${c.atk}",if(selected==i) Color.Green else Color.Gray); Text("DEF ${c.def}") } } }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Button(enabled=selected in hand.indices && played==null && playerLp>0 && cpuLp>0,onClick={played=hand[selected]}) { Text("Summon") }
            Button(enabled=played!=null && playerLp>0 && cpuLp>0,onClick={ val a=played!!.atk; val b=cpu.atk; if(a>=b) cpuLp=(cpuLp-(a-b).coerceAtLeast(300)).coerceAtLeast(0) else playerLp=(playerLp-(b-a)).coerceAtLeast(0); played=null;selected=-1;turn++ }) { Text("Attack / End turn") }
        }
        if(cpuLp==0 || playerLp==0) Text(if(cpuLp==0) "YOU WIN!" else "CPU WINS",style=MaterialTheme.typography.headlineMedium)
        OutlinedButton(onClick={turn=0;playerLp=4000;cpuLp=4000;played=null;selected=-1}){Text("New duel")}
        Text("Simplified photo battle: no original photos are modified.",style=MaterialTheme.typography.bodySmall)
    }
}
